import images from './images';
import icons from './icons';
import {STRING} from './String';
import {Constant} from './Constant';
import {SIZES} from './themes';

export {images, icons, STRING, SIZES, Constant};
