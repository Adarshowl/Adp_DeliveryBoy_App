import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const OtpVerification = () => {
  return (
    <View>
      <Text>OtpVerification</Text>
    </View>
  );
};

export default OtpVerification;

const styles = StyleSheet.create({});
